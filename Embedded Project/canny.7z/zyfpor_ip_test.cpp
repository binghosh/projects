
#include "zyfpor_ip_top.h"
#include "hls_opencv.h"
#include <stdio.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

using namespace std;


int main () {

	// if not defined --> video input is used!!!
	#define use_iplimage ;

	#if defined use_iplimage
	{
		// image input
		// comment out the respective test image
		//IplImage* src = cvLoadImage("testimages/test_1080p.bmp");
		//IplImage* src = cvLoadImage("testimages/Lena.bmp");
		IplImage* src = cvLoadImage("test_1080p.bmp");
		IplImage* dst = cvCreateImage(cvGetSize(src), src->depth, 1);
		//IplImage* test = cvCreateImage(cvSize(src->width, src->height), IPL_DEPTH_8U, 1);
		//IplImage* test = cvCreateImage(cvGetSize(src), src->depth, 1);

		cv::namedWindow("Input Image");
		cv::namedWindow("Output Image");

		// processing in Hardware
		AXI_STREAM_IN  src_axi;
		AXI_STREAM_OUT dst_axi;
		//image to video conversion for processing
		IplImage2AXIvideo(src, src_axi);
		//our filter
		image_filter(src_axi, dst_axi, src->height, src->width/*, number_pixels_line, lines_angle_tb, lines_rho_tb*/);
		//video to image
		AXIvideo2IplImage(dst_axi, dst);
		cvShowImage("Output Image", dst);

		//Showing the images and conversion to cv::Mat
		cvShowImage("Input Image", src);

		while(1)
		{
			if (cv::waitKey(30) >= 0)
				break;
		}
		cvReleaseImage(&src);
		cvReleaseImage(&dst);

		return 0;
	}
	#else
	{


		// comment out the respective test sequence
		//CvCapture* cap = cvCaptureFromFile("testimages/yellow.avi");
		//CvCapture* cap = cvCaptureFromFile("testimages/video.mov");
		//CvCapture* cap = cvCaptureFromFile("Wildlife.wmv");
		CvCapture* cap = cvCaptureFromCAM(0);
		//CvCapture* cap = cvCaptureFromFile("testimages/sequences_C910/video_1.mov");
		cv::Mat grayImage;
		IplImage* src;
		IplImage* test = NULL;
		IplImage* dst = NULL;

		unsigned int number_pixels_line = 250;

		AXI_STREAM_IN  src_axi;
		AXI_STREAM_OUT dst_axi;

		cvNamedWindow("Input Video");
		cvNamedWindow("Output Video");
		//check if something captured
		if (!cap) {
			cout << "Can not open a capture object." << endl;
			return -1;
		}

		for(;;) {

			src = cvQueryFrame(cap);
			//cap >> src;

			if (!src) {
				cout << "Can not query frames." << endl;
				return -1;
			}

			// processing in Hardware
			IplImage2AXIvideo(src, src_axi);
			//apply filter
			image_filter(src_axi, dst_axi, src->height, src->width, number_pixels_line, lines_angle_tb, lines_rho_tb);

			if(dst == NULL)
				dst = cvCreateImage(cvSize(src->width, src->height), IPL_DEPTH_8U, 1);	//src->nChannels
			if(test == NULL)
				test = cvCreateImage(cvSize(src->width, src->height), IPL_DEPTH_8U, 1);	//src->nChannels
			AXIvideo2IplImage(dst_axi, dst);

			cvCopy(dst, test);

			// read out lines angle and rho
			for( unsigned int i = 0; i < MAX_LINES; i++ )
			{
			   	theta = lines_angle_tb[i].to_float();
			    rho = lines_rho_tb[i].to_float();

			    cv::Point pt1, pt2;
			    double a = cos(theta), b = sin(theta);
			    double x0 = a*rho, y0 = b*rho;
			    pt1.x = cvRound(x0 + 1000*(-b));
			    pt1.y = cvRound(y0 + 1000*(a));
			    pt2.x = cvRound(x0 - 1000*(-b));
			    pt2.y = cvRound(y0 - 1000*(a));
			    cvLine(dst, pt1, pt2, cv::Scalar(255,0,0), 3, 8, 0);
			}

			cvShowImage("Input Video", src);
			cvShowImage("Output Video", dst);

			if (cv::waitKey(30) >= 0)
				break;
		}

		cvReleaseCapture(&cap);
		cvReleaseImage(&src);
		cvReleaseImage(&dst);
		cvDestroyAllWindows();

	}
	#endif

	return 0;
}
