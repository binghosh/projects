
#include "zyfpor_ip_top.h"

void image_filter(AXI_STREAM_IN& INPUT_STREAM, AXI_STREAM_OUT& OUTPUT_STREAM, int rows, int cols){

//Create AXI streaming interfaces for the core
#pragma HLS INTERFACE axis port=INPUT_STREAM
#pragma HLS INTERFACE axis port=OUTPUT_STREAM

// pragma RESOURCE
#pragma HLS RESOURCE core=AXI_SLAVE variable=rows metadata="-bus_bundle CONTROL_BUS"
#pragma HLS RESOURCE core=AXI_SLAVE variable=cols metadata="-bus_bundle CONTROL_BUS"
//#pragma HLS RESOURCE core=AXI_SLAVE variable=number_pixels_line metadata="-bus_bundle CONTROL_BUS"
#pragma HLS RESOURCE core=AXI_SLAVE variable=return metadata="-bus_bundle CONTROL_BUS"
//#pragma HLS RESOURCE variable=lines_angle core=RAM_1P_BRAM metadata="-bus_bundle CONTROL_BUS"
//#pragma HLS RESOURCE variable=lines_rho core=RAM_1P_BRAM metadata="-bus_bundle CONTROL_BUS"

// pragma INTERFACE
#pragma HLS INTERFACE ap_stable port=rows
#pragma HLS INTERFACE ap_stable port=cols
//#pragma HLS INTERFACE ap_stable port=number_pixels_line
//#pragma HLS INTERFACE ap_memory port=lines_angle
//#pragma HLS INTERFACE ap_memory port=lines_rho

    //declare image variables to be used
    RGB_IMAGE input_img(rows, cols);
    GRAY_IMAGE gray_img(rows, cols);
    GRAY_IMAGE gray_img_reduced_noise(rows, cols);
    GRAY_IMAGE gray_img1(rows, cols);
    GRAY_IMAGE gray_img2(rows, cols);
    GRAY_IMAGE sobel_out_hori(rows, cols);
    GRAY_IMAGE sobel_out_vert(rows, cols);
    GRAY_IMAGE sobel_out(rows, cols);
    GRAY_IMAGE threshold_image(rows, cols);
    GRAY_IMAGE eroded_image(rows, cols);
    RGB_IMAGE output_img_gray(rows, cols);


#pragma HLS dataflow
    // input stream has a width of 24 Bit (RGB)
    hls::AXIvideo2Mat(INPUT_STREAM, input_img); //video to MAT conversion
    hls::CvtColor<HLS_BGR2GRAY>(input_img, gray_img); // conversion to gray image format
    hls::GaussianBlur<5,5>(gray_img, gray_img_reduced_noise);	//smoothen the image  	// does not work with kernel size of 3x3
    hls::Duplicate(gray_img_reduced_noise, gray_img1, gray_img2);
    hls::Sobel<1,0,3>(gray_img1, sobel_out_hori); //apply sobel filter on vertical and horizontal components
    hls::Sobel<0,1,3>(gray_img2, sobel_out_vert);

    // combine the 2 sobel images to one using AddWeighted
    hls::AddWeighted(sobel_out_hori, 1, sobel_out_vert, 1, 0, sobel_out); //combine the two sobel filter output components

    hls::Threshold(sobel_out, threshold_image, 20, 255, HLS_THRESH_BINARY); // thresholding to find edges

    hls::Erode(threshold_image, eroded_image);


    // output stream has a width of 24 Bit (Grayscale)
    hls::CvtColor<HLS_GRAY2RGB>(eroded_image, output_img_gray);

    hls::Mat2AXIvideo(output_img_gray, OUTPUT_STREAM); // MAT to video
}
