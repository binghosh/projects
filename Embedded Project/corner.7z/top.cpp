#include "top.h"

void image_filter_corner(AXI_STREAM& INPUT_STREAM, AXI_STREAM& OUTPUT_STREAM, int rows, int cols)
{
//Create AXI streaming interfaces for the core
#pragma HLS INTERFACE axis port=INPUT_STREAM
#pragma HLS INTERFACE axis port=OUTPUT_STREAM

#pragma HLS RESOURCE core=AXI_SLAVE variable=rows metadata="-bus_bundle CONTROL_BUS"
#pragma HLS RESOURCE core=AXI_SLAVE variable=cols metadata="-bus_bundle CONTROL_BUS"
#pragma HLS RESOURCE core=AXI_SLAVE variable=return metadata="-bus_bundle CONTROL_BUS"

#pragma HLS INTERFACE ap_stable port=rows
#pragma HLS INTERFACE ap_stable port=cols
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC3>      _src(rows,cols);
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC3>      _dst(rows,cols);
#pragma HLS dataflow
    hls::AXIvideo2Mat(INPUT_STREAM, _src);
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC3>      src0(rows,cols);
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC3>      src1(rows,cols);
#pragma HLS stream depth=20000 variable=src1.data_stream
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC1>      mask(rows,cols);
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC1>      dmask(rows,cols);
    hls::Scalar<3,unsigned char> color(255,0,0);
    hls::Duplicate(_src,src0,src1);
    hls::Mat<MAX_HEIGHT,MAX_WIDTH,HLS_8UC1>      gray(rows,cols);
    hls::CvtColor<HLS_BGR2GRAY>(src0,gray);
    hls::FASTX(gray,mask,20,true);
    hls::Dilate(mask,dmask);
    hls::PaintMask(src1,dmask,_dst,color);
    hls::Mat2AXIvideo(_dst, OUTPUT_STREAM);
}
