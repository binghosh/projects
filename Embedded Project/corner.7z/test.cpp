#include "top.h"
#include "opencv_top.h"


int main (int argc, char** argv) {

    IplImage* src = cvLoadImage("bldng.jpg");
    IplImage* dst = cvCreateImage(cvGetSize(src), src->depth, src->nChannels);
    
    AXI_STREAM  src_axi, dst_axi;
    IplImage2AXIvideo(src, src_axi);

    cv::namedWindow("Input Image");
    cv::namedWindow("Output Image");
    cv::namedWindow("Output Image1");

//apply filter
    image_filter_corner(src_axi, dst_axi, src->height, src->width);

    AXIvideo2IplImage(dst_axi, dst);

    //#define OUTPUT_IMAGE_GOLDEN   "result_1080p_golden.bmp"


    cvShowImage("Input Image", src);
    cvShowImage("Output Image", dst);
    
    cv::waitKey(0);			// necessary to show the images using imshow!!!

    cvReleaseImage(&src);
    cvReleaseImage(&dst);
    int ret = 0;
    return ret;

}
